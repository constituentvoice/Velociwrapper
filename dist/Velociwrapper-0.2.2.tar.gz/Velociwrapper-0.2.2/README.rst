Velociwrapper
=============

Velociwrapper is a wrapper to create models around ElasticSearch
