__version__ = '1.0.12' # make sure to keep updated
