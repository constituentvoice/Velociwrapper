from .collection import VWCollection,NoResultsFound
from .base import VWBase,ObjectDeletedError
from .relationship import relationship

# make sure this gets updated!
__version__ = '1.0.9'
