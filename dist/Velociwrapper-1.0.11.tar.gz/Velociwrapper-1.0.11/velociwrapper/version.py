__version__ = '1.0.11' # make sure to keep updated
